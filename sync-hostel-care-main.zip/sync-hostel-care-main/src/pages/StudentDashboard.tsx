import { Routes, Route } from "react-router-dom";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { StatusTracker, StatCard, PriorityBadge, StatusBadge } from "@/components/dashboard/DashboardWidgets";
import { FileText, Clock, CheckCircle2, Bell, Mic, Upload, Star, Search, Filter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";

const navItems = [
  { label: "Dashboard", href: "/student", icon: <FileText className="h-4 w-4" /> },
  { label: "Raise Complaint", href: "/student/new", icon: <Mic className="h-4 w-4" /> },
  { label: "My Complaints", href: "/student/complaints", icon: <Clock className="h-4 w-4" /> },
  { label: "Notifications", href: "/student/notifications", icon: <Bell className="h-4 w-4" /> },
];

const sampleComplaints = [
  { id: "TKT-2024-001", domain: "Electrical", desc: "Ceiling fan not working in Room 204", status: "In Progress", priority: "high" as const, date: "2024-03-15" },
  { id: "TKT-2024-002", domain: "Plumbing", desc: "Water leakage in bathroom", status: "Assigned", priority: "high" as const, date: "2024-03-14" },
  { id: "TKT-2024-003", domain: "Internet", desc: "WiFi connectivity issue on 3rd floor", status: "Resolved", priority: "medium" as const, date: "2024-03-12" },
  { id: "TKT-2024-004", domain: "Cleaning", desc: "Common area not cleaned for 2 days", status: "Submitted", priority: "low" as const, date: "2024-03-11" },
  { id: "TKT-2024-005", domain: "Furniture", desc: "Broken chair in study room", status: "Accepted", priority: "medium" as const, date: "2024-03-10" },
];

function Overview() {
  const currentSteps = [
    { label: "Submitted", completed: true, active: false },
    { label: "Accepted", completed: true, active: false },
    { label: "Assigned", completed: true, active: false },
    { label: "In Progress", completed: false, active: true },
    { label: "Resolved", completed: false, active: false },
    { label: "Feedback", completed: false, active: false },
  ];

  return (
    <div className="space-y-6">
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Total Complaints" value={12} icon={<FileText className="h-5 w-5 text-primary" />} />
        <StatCard label="Pending" value={3} icon={<Clock className="h-5 w-5 text-primary" />} trend="-2 this week" />
        <StatCard label="Resolved" value={8} icon={<CheckCircle2 className="h-5 w-5 text-primary" />} trend="+5 this month" />
        <StatCard label="Avg. Resolution" value="4.2 hrs" icon={<Star className="h-5 w-5 text-primary" />} />
      </div>

      <div className="rounded-xl border border-border bg-card p-6 shadow-card">
        <h3 className="font-semibold mb-4">Latest Complaint Progress</h3>
        <StatusTracker steps={currentSteps} />
        <div className="mt-4 p-3 rounded-lg bg-muted text-sm">
          <span className="font-medium">TKT-2024-001</span> — Ceiling fan not working in Room 204
        </div>
      </div>

      <div className="rounded-xl border border-border bg-card shadow-card overflow-hidden">
        <div className="p-4 border-b border-border flex items-center justify-between">
          <h3 className="font-semibold">Recent Complaints</h3>
          <Button variant="outline" size="sm" className="gap-1"><Filter className="h-3 w-3" /> Filter</Button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-border bg-muted/50">
              <th className="text-left p-3 font-medium text-muted-foreground">Ticket</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Domain</th>
              <th className="text-left p-3 font-medium text-muted-foreground hidden md:table-cell">Description</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Priority</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Status</th>
            </tr></thead>
            <tbody>
              {sampleComplaints.map((c) => (
                <tr key={c.id} className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors">
                  <td className="p-3 font-mono text-xs">{c.id}</td>
                  <td className="p-3">{c.domain}</td>
                  <td className="p-3 text-muted-foreground hidden md:table-cell max-w-[200px] truncate">{c.desc}</td>
                  <td className="p-3"><PriorityBadge priority={c.priority} /></td>
                  <td className="p-3"><StatusBadge status={c.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function NewComplaint() {
  return (
    <div className="max-w-2xl space-y-6">
      <div>
        <h2 className="text-xl font-bold">Raise New Complaint</h2>
        <p className="text-sm text-muted-foreground">Fill in the details below to submit a maintenance complaint</p>
      </div>
      <div className="rounded-xl border border-border bg-card p-6 shadow-card space-y-4">
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <Label>Domain</Label>
            <Select>
              <SelectTrigger className="mt-1.5"><SelectValue placeholder="Select domain" /></SelectTrigger>
              <SelectContent>
                {["Electrical", "Plumbing", "Cleaning", "Internet", "Furniture", "Others"].map(d => (
                  <SelectItem key={d} value={d.toLowerCase()}>{d}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Room Number</Label>
            <Input placeholder="e.g. 204" className="mt-1.5" />
          </div>
        </div>
        <div>
          <Label>Description</Label>
          <Textarea placeholder="Describe the issue in detail..." className="mt-1.5" rows={4} />
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="gap-2"><Mic className="h-4 w-4" /> Voice-to-Text</Button>
          <Button variant="outline" className="gap-2"><Upload className="h-4 w-4" /> Attach Image</Button>
        </div>
        <div className="p-3 rounded-lg bg-muted text-sm">
          <span className="text-muted-foreground">Auto Ticket ID:</span>{" "}
          <span className="font-mono font-medium">TKT-2024-006</span>
        </div>
        <Button className="w-full" size="lg">Submit Complaint</Button>
      </div>
    </div>
  );
}

function Complaints() {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search complaints..." className="pl-9" />
        </div>
        <Button variant="outline" size="sm" className="gap-1"><Filter className="h-3 w-3" /> Filters</Button>
      </div>
      <div className="rounded-xl border border-border bg-card shadow-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-border bg-muted/50">
              <th className="text-left p-3 font-medium text-muted-foreground">Ticket</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Domain</th>
              <th className="text-left p-3 font-medium text-muted-foreground hidden md:table-cell">Description</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Date</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Priority</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Status</th>
            </tr></thead>
            <tbody>
              {sampleComplaints.map(c => (
                <tr key={c.id} className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors">
                  <td className="p-3 font-mono text-xs">{c.id}</td>
                  <td className="p-3">{c.domain}</td>
                  <td className="p-3 text-muted-foreground hidden md:table-cell max-w-[200px] truncate">{c.desc}</td>
                  <td className="p-3 text-muted-foreground">{c.date}</td>
                  <td className="p-3"><PriorityBadge priority={c.priority} /></td>
                  <td className="p-3"><StatusBadge status={c.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function Notifications() {
  const notifs = [
    { msg: "Your complaint TKT-2024-001 has been assigned to a worker.", time: "2 hours ago" },
    { msg: "Complaint TKT-2024-003 has been resolved. Please submit feedback.", time: "1 day ago" },
    { msg: "Your complaint TKT-2024-004 has been accepted by the warden.", time: "2 days ago" },
  ];
  return (
    <div className="max-w-2xl space-y-3">
      {notifs.map((n, i) => (
        <div key={i} className="rounded-xl border border-border bg-card p-4 shadow-card flex items-start gap-3">
          <div className="h-8 w-8 rounded-lg gradient-hero-soft flex items-center justify-center flex-shrink-0 mt-0.5">
            <Bell className="h-4 w-4 text-primary" />
          </div>
          <div>
            <p className="text-sm">{n.msg}</p>
            <p className="text-xs text-muted-foreground mt-1">{n.time}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

export default function StudentDashboard() {
  return (
    <DashboardLayout role="student" navItems={navItems} userName="Priya Sharma">
      <Routes>
        <Route index element={<Overview />} />
        <Route path="new" element={<NewComplaint />} />
        <Route path="complaints" element={<Complaints />} />
        <Route path="notifications" element={<Notifications />} />
      </Routes>
    </DashboardLayout>
  );
}
