import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Activity, Shield, Users, Globe, Mic, BarChart3, AlertTriangle,
  ArrowRight, CheckCircle2,
  Building2, Wrench, GraduationCap, Lock
} from "lucide-react";
import { Button } from "@/components/ui/button";
import heroImg from "@/assets/hero-illustration.jpg";
import AIChatbot from "@/components/AIChatbot";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.1, duration: 0.5 } }),
};

const features = [
  { icon: Activity, title: "Real-Time Tracking", desc: "Monitor complaint progress live from submission to resolution" },
  { icon: Shield, title: "Role-Based Access", desc: "Secure access control for students, wardens, workers & admins" },
  { icon: Users, title: "Gender-Based Access", desc: "Gender-appropriate routing for hostel-specific complaints" },
  { icon: Wrench, title: "Domain Assignment", desc: "Auto-assign workers based on complaint domain expertise" },
  { icon: Mic, title: "Voice-to-Text Entry", desc: "Submit complaints using speech recognition for quick entry" },
  { icon: Globe, title: "Multilingual Support", desc: "Support for multiple languages across the platform" },
  { icon: AlertTriangle, title: "Priority Escalation", desc: "Auto-escalate unresolved issues based on time thresholds" },
  { icon: BarChart3, title: "Analytics Dashboard", desc: "Comprehensive insights into complaint patterns and performance" },
];


const steps = [
  { num: 1, title: "Student Raises Complaint", desc: "Submit via form or voice with domain, priority, and attachments", icon: GraduationCap },
  { num: 2, title: "Warden Reviews", desc: "Hostel warden reviews, accepts, and assigns priority", icon: Building2 },
  { num: 3, title: "Worker Assigned", desc: "Domain-matched worker receives task with all details", icon: Wrench },
  { num: 4, title: "Progress Updated", desc: "Real-time status updates visible to all stakeholders", icon: Activity },
  { num: 5, title: "Resolved + Feedback", desc: "Issue marked resolved, student submits satisfaction rating", icon: CheckCircle2 },
];



export default function Index() {
  return (
    <div className="min-h-screen gradient-page">
      {/* Navbar */}
      <nav className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-lg">
        <div className="container flex h-16 items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg gradient-hero">
              <Building2 className="h-4 w-4 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold">Hostel Sync</span>
          </Link>
          <div className="hidden md:flex items-center gap-6 text-sm text-muted-foreground">
            <a href="#features" className="hover:text-foreground transition-colors">Features</a>
            <a href="#how-it-works" className="hover:text-foreground transition-colors">How It Works</a>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="ghost" asChild><Link to="/login">Login</Link></Button>
            <Button asChild><Link to="/register">Get Started</Link></Button>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="container py-20 lg:py-28">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div initial="hidden" animate="visible" className="space-y-6">
            <motion.div variants={fadeUp} custom={0} className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-1.5 text-sm shadow-card">
              <Lock className="h-3.5 w-3.5 text-primary" />
              <span className="text-muted-foreground">Secure Role-Based System</span>
            </motion.div>
            <motion.h1 variants={fadeUp} custom={1} className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-[1.1]">
              <span className="text-gradient">Hostel Sync</span>
            </motion.h1>
            <motion.p variants={fadeUp} custom={2} className="text-xl sm:text-2xl text-muted-foreground font-medium">
              Digital Hostel Complaint & Maintenance Management System
            </motion.p>
            <motion.p variants={fadeUp} custom={3} className="text-muted-foreground max-w-lg leading-relaxed">
              Replace outdated manual logbooks with an intelligent, role-based digital platform. Track complaints in real-time, assign workers automatically, and ensure accountability at every step.
            </motion.p>
            <motion.div variants={fadeUp} custom={4} className="flex flex-wrap gap-3 pt-2">
              <Button size="lg" asChild className="gap-2">
                <Link to="/register">Get Started <ArrowRight className="h-4 w-4" /></Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link to="/login">Login to Dashboard</Link>
              </Button>
            </motion.div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="relative"
          >
            <div className="rounded-2xl overflow-hidden shadow-card-hover border border-border">
              <img src={heroImg} alt="Hostel Sync Dashboard" className="w-full h-auto" />
            </div>
            <div className="absolute -bottom-4 -left-4 rounded-xl bg-card border border-border shadow-card p-3 flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg gradient-hero flex items-center justify-center">
                <CheckCircle2 className="h-5 w-5 text-primary-foreground" />
              </div>
              <div>
                <p className="text-sm font-semibold">98% Resolution Rate</p>
                <p className="text-xs text-muted-foreground">Avg. 4hrs response time</p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>


      {/* Features */}
      <section id="features" className="container py-20">
        <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} className="text-center mb-12">
          <motion.p variants={fadeUp} custom={0} className="text-sm font-semibold text-primary uppercase tracking-wider mb-2">Features</motion.p>
          <motion.h2 variants={fadeUp} custom={1} className="text-3xl sm:text-4xl font-bold mb-4">Everything You Need</motion.h2>
          <motion.p variants={fadeUp} custom={2} className="text-muted-foreground max-w-2xl mx-auto">A comprehensive platform designed to handle every aspect of hostel maintenance management.</motion.p>
        </motion.div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((f, i) => (
            <motion.div key={f.title} initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} custom={i}
              className="group rounded-xl border border-border bg-card p-6 shadow-card hover:shadow-card-hover hover:border-primary/20 transition-all">
              <div className="h-10 w-10 rounded-lg gradient-hero-soft flex items-center justify-center mb-4 group-hover:shadow-glow transition-shadow">
                <f.icon className="h-5 w-5 text-primary" />
              </div>
              <h3 className="font-semibold mb-1">{f.title}</h3>
              <p className="text-sm text-muted-foreground">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="container py-20">
        <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} className="text-center mb-16">
          <motion.p variants={fadeUp} custom={0} className="text-sm font-semibold text-primary uppercase tracking-wider mb-2">Process</motion.p>
          <motion.h2 variants={fadeUp} custom={1} className="text-3xl sm:text-4xl font-bold mb-4">How It Works</motion.h2>
        </motion.div>
        <div className="relative max-w-3xl mx-auto">
          {/* Vertical line */}
          <div className="absolute left-6 top-0 bottom-0 w-px bg-border hidden md:block" />
          <div className="space-y-8">
            {steps.map((s, i) => (
              <motion.div key={s.num} initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} custom={i}
                className="flex gap-6 items-start">
                <div className="relative z-10 flex-shrink-0 h-12 w-12 rounded-xl gradient-hero flex items-center justify-center text-primary-foreground font-bold text-lg shadow-glow">
                  {s.num}
                </div>
                <div className="rounded-xl border border-border bg-card p-5 shadow-card flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <s.icon className="h-4 w-4 text-primary" />
                    <h3 className="font-semibold">{s.title}</h3>
                  </div>
                  <p className="text-sm text-muted-foreground">{s.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>


      {/* CTA */}
      <section className="container py-20">
        <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }}
          className="rounded-2xl gradient-hero p-12 text-center text-primary-foreground">
          <motion.h2 variants={fadeUp} custom={0} className="text-3xl sm:text-4xl font-bold mb-4">Ready to Modernize Your Hostel?</motion.h2>
          <motion.p variants={fadeUp} custom={1} className="text-primary-foreground/80 max-w-xl mx-auto mb-8">
            Join institutions already using Hostel Sync to manage complaints efficiently and transparently.
          </motion.p>
          <motion.div variants={fadeUp} custom={2}>
            <Button size="lg" variant="secondary" asChild className="gap-2">
              <Link to="/register">Get Started Free <ArrowRight className="h-4 w-4" /></Link>
            </Button>
          </motion.div>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-card">
        <div className="container py-12">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <div className="h-7 w-7 rounded-md gradient-hero flex items-center justify-center">
                  <Building2 className="h-3.5 w-3.5 text-primary-foreground" />
                </div>
                <span className="font-bold">Hostel Sync</span>
              </div>
              <p className="text-sm text-muted-foreground">Secure role-based hostel complaint & maintenance management system.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-3 text-sm">Product</h4>
              <div className="space-y-2 text-sm text-muted-foreground">
                <a href="#features" className="block hover:text-foreground transition-colors">Features</a>
                <a href="#how-it-works" className="block hover:text-foreground transition-colors">How It Works</a>
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-3 text-sm">Dashboards</h4>
              <div className="space-y-2 text-sm text-muted-foreground">
                <Link to="/student" className="block hover:text-foreground transition-colors">Student</Link>
                <Link to="/warden" className="block hover:text-foreground transition-colors">Warden</Link>
                <Link to="/worker" className="block hover:text-foreground transition-colors">Worker</Link>
                <Link to="/admin" className="block hover:text-foreground transition-colors">Admin</Link>
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-3 text-sm">Legal</h4>
              <div className="space-y-2 text-sm text-muted-foreground">
                <a href="#" className="block hover:text-foreground transition-colors">Privacy Policy</a>
                <a href="#" className="block hover:text-foreground transition-colors">Terms of Service</a>
                <a href="#" className="block hover:text-foreground transition-colors">Contact Us</a>
              </div>
            </div>
          </div>
          <div className="border-t border-border mt-8 pt-8 text-center text-sm text-muted-foreground">
            © {new Date().getFullYear()} Hostel Sync. All rights reserved.
          </div>
        </div>
      </footer>

      {/* AI Chatbot */}
      <AIChatbot />
    </div>
  );
}
