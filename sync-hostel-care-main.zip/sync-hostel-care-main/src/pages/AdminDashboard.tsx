import { Routes, Route } from "react-router-dom";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { StatCard, StatusBadge } from "@/components/dashboard/DashboardWidgets";
import { LayoutDashboard, Users, FileText, BarChart3, Download, Shield, CheckCircle2, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";

const navItems = [
  { label: "Overview", href: "/admin", icon: <LayoutDashboard className="h-4 w-4" /> },
  { label: "Users", href: "/admin/users", icon: <Users className="h-4 w-4" /> },
  { label: "Complaints", href: "/admin/complaints", icon: <FileText className="h-4 w-4" /> },
  { label: "Reports", href: "/admin/reports", icon: <BarChart3 className="h-4 w-4" /> },
  { label: "Audit Log", href: "/admin/audit", icon: <Shield className="h-4 w-4" /> },
];

const users = [
  { name: "Priya Sharma", email: "priya@uni.edu", role: "Student", hostel: "Girls Hostel A", status: "Active" },
  { name: "Dr. Meena Gupta", email: "meena@uni.edu", role: "Warden", hostel: "Girls Hostel A", status: "Active" },
  { name: "Raju Kumar", email: "raju@uni.edu", role: "Worker", hostel: "All", status: "Active" },
  { name: "Rahul Khanna", email: "rahul@uni.edu", role: "Student", hostel: "Boys Hostel B", status: "Active" },
  { name: "Suresh Yadav", email: "suresh@uni.edu", role: "Worker", hostel: "All", status: "Pending" },
];

const auditLog = [
  { action: "User suresh@uni.edu registered as Worker", by: "System", time: "10 min ago" },
  { action: "Complaint TKT-2024-005 resolved", by: "Raju Kumar", time: "1 hour ago" },
  { action: "Worker Raju Kumar approved", by: "Admin", time: "3 hours ago" },
  { action: "New hostel Girls Hostel C created", by: "Admin", time: "1 day ago" },
  { action: "Complaint TKT-2024-001 escalated to high", by: "Dr. Meena Gupta", time: "1 day ago" },
];

function Overview() {
  return (
    <div className="space-y-6">
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Total Users" value={156} icon={<Users className="h-5 w-5 text-primary" />} trend="+12 this month" />
        <StatCard label="Total Complaints" value={324} icon={<FileText className="h-5 w-5 text-primary" />} />
        <StatCard label="Resolution Rate" value="94%" icon={<CheckCircle2 className="h-5 w-5 text-primary" />} trend="+2% vs last month" />
        <StatCard label="Avg. Response" value="2.3 hrs" icon={<Clock className="h-5 w-5 text-primary" />} />
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="rounded-xl border border-border bg-card p-6 shadow-card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">System Health</h3>
            <span className="inline-flex items-center gap-1.5 text-xs font-medium text-success"><span className="h-2 w-2 rounded-full bg-success animate-pulse-soft" /> All systems operational</span>
          </div>
          <div className="space-y-3">
            {[
              { label: "Complaint Processing", value: "99.9% uptime" },
              { label: "Worker Assignment Engine", value: "Active" },
              { label: "Notification Service", value: "Active" },
              { label: "Analytics Pipeline", value: "Active" },
            ].map(s => (
              <div key={s.label} className="flex justify-between text-sm py-2 border-b border-border last:border-0">
                <span className="text-muted-foreground">{s.label}</span>
                <span className="font-medium">{s.value}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-xl border border-border bg-card p-6 shadow-card">
          <h3 className="font-semibold mb-4">Recent Audit Log</h3>
          <div className="space-y-3">
            {auditLog.slice(0, 4).map((a, i) => (
              <div key={i} className="flex items-start gap-3 text-sm">
                <div className="h-2 w-2 rounded-full gradient-hero flex-shrink-0 mt-1.5" />
                <div className="flex-1">
                  <p>{a.action}</p>
                  <p className="text-xs text-muted-foreground">{a.by} • {a.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function UsersPage() {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Manage Users</h2>
        <Button size="sm" className="gap-1"><Users className="h-3.5 w-3.5" /> Add User</Button>
      </div>
      <div className="rounded-xl border border-border bg-card shadow-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-border bg-muted/50">
              <th className="text-left p-3 font-medium text-muted-foreground">Name</th>
              <th className="text-left p-3 font-medium text-muted-foreground hidden md:table-cell">Email</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Role</th>
              <th className="text-left p-3 font-medium text-muted-foreground hidden lg:table-cell">Hostel</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Status</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Actions</th>
            </tr></thead>
            <tbody>
              {users.map(u => (
                <tr key={u.email} className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors">
                  <td className="p-3 font-medium">{u.name}</td>
                  <td className="p-3 text-muted-foreground hidden md:table-cell">{u.email}</td>
                  <td className="p-3"><StatusBadge status={u.role} /></td>
                  <td className="p-3 hidden lg:table-cell text-muted-foreground">{u.hostel}</td>
                  <td className="p-3"><StatusBadge status={u.status} /></td>
                  <td className="p-3">
                    {u.status === "Pending" ? (
                      <Button size="sm" variant="outline" className="gap-1 text-xs"><CheckCircle2 className="h-3 w-3" /> Approve</Button>
                    ) : (
                      <Button size="sm" variant="ghost" className="text-xs">Edit</Button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function Reports() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Reports & Analytics</h2>
        <Button variant="outline" size="sm" className="gap-1"><Download className="h-3.5 w-3.5" /> Export CSV</Button>
      </div>
      <div className="text-center py-12 text-muted-foreground rounded-xl border border-border bg-card shadow-card">
        <BarChart3 className="h-12 w-12 mx-auto mb-4 opacity-30" />
        <p className="font-medium">Analytics Dashboard</p>
        <p className="text-sm">Connect to a backend to view real-time charts and reports</p>
      </div>
    </div>
  );
}

function AuditLog() {
  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold">Audit Log</h2>
      <div className="space-y-3">
        {auditLog.map((a, i) => (
          <div key={i} className="rounded-xl border border-border bg-card p-4 shadow-card flex items-start gap-3">
            <div className="h-8 w-8 rounded-lg gradient-hero-soft flex items-center justify-center flex-shrink-0 mt-0.5">
              <Shield className="h-4 w-4 text-primary" />
            </div>
            <div>
              <p className="text-sm">{a.action}</p>
              <p className="text-xs text-muted-foreground mt-1">{a.by} • {a.time}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function AdminComplaints() {
  return (
    <div className="text-center py-12 text-muted-foreground rounded-xl border border-border bg-card shadow-card">
      <FileText className="h-12 w-12 mx-auto mb-4 opacity-30" />
      <p className="font-medium">All System Complaints</p>
      <p className="text-sm">View and monitor all complaints across hostels</p>
    </div>
  );
}

export default function AdminDashboard() {
  return (
    <DashboardLayout role="admin" navItems={navItems} userName="Admin User">
      <Routes>
        <Route index element={<Overview />} />
        <Route path="users" element={<UsersPage />} />
        <Route path="complaints" element={<AdminComplaints />} />
        <Route path="reports" element={<Reports />} />
        <Route path="audit" element={<AuditLog />} />
      </Routes>
    </DashboardLayout>
  );
}
