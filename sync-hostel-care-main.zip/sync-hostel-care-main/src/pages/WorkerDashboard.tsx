import { Routes, Route } from "react-router-dom";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { StatCard, PriorityBadge, StatusBadge } from "@/components/dashboard/DashboardWidgets";
import { Wrench, CheckCircle2, Upload, Volume2, Play, Pause, RotateCcw, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";

const navItems = [
  { label: "My Tasks", href: "/worker", icon: <Wrench className="h-4 w-4" /> },
  { label: "Completed", href: "/worker/completed", icon: <CheckCircle2 className="h-4 w-4" /> },
  { label: "Performance", href: "/worker/performance", icon: <Star className="h-4 w-4" /> },
];

const tasks = [
  { id: "TKT-2024-001", domain: "Electrical", desc: "Ceiling fan not working in Room 204. The fan makes grinding noise and stops after few minutes of operation.", room: "204", hostel: "Girls Hostel A", priority: "high" as const, status: "In Progress" },
  { id: "TKT-2024-002", domain: "Plumbing", desc: "Water leakage in bathroom. The pipe under the sink is dripping continuously.", room: "112", hostel: "Boys Hostel B", priority: "high" as const, status: "Assigned" },
  { id: "TKT-2024-004", domain: "Electrical", desc: "Light switch not working in corridor near Room 301.", room: "Corridor", hostel: "Boys Hostel A", priority: "medium" as const, status: "Assigned" },
];

function TTSButton({ text }: { text: string }) {
  const [playing, setPlaying] = useState(false);

  return (
    <div className="flex items-center gap-2">
      <Button size="sm" variant="outline" className="gap-2" onClick={() => setPlaying(!playing)}>
        {playing ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
        <Volume2 className="h-3.5 w-3.5" />
        {playing ? "Pause" : "Listen"}
      </Button>
      <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => setPlaying(false)}>
        <RotateCcw className="h-3.5 w-3.5" />
      </Button>
    </div>
  );
}

function MyTasks() {
  return (
    <div className="space-y-6">
      <div className="grid sm:grid-cols-3 gap-4">
        <StatCard label="Assigned Tasks" value={3} icon={<Wrench className="h-5 w-5 text-primary" />} />
        <StatCard label="Completed Today" value={2} icon={<CheckCircle2 className="h-5 w-5 text-primary" />} />
        <StatCard label="Rating" value="4.7★" icon={<Star className="h-5 w-5 text-primary" />} />
      </div>

      <div className="space-y-4">
        {tasks.map(t => (
          <div key={t.id} className="rounded-xl border border-border bg-card p-5 shadow-card space-y-3">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-mono text-xs text-muted-foreground">{t.id}</span>
                  <PriorityBadge priority={t.priority} />
                  <StatusBadge status={t.status} />
                </div>
                <h3 className="font-semibold">{t.domain} Issue</h3>
              </div>
            </div>

            <p className="text-sm text-muted-foreground">{t.desc}</p>

            <div className="flex items-center gap-4 text-xs text-muted-foreground">
              <span>🏠 {t.hostel}</span>
              <span>🚪 Room {t.room}</span>
            </div>

            {/* TTS Feature */}
            <div className="p-3 rounded-lg bg-muted">
              <p className="text-xs text-muted-foreground mb-2">🔊 Text-to-Speech — Listen to complaint details</p>
              <TTSButton text={t.desc} />
            </div>

            <div className="flex flex-wrap gap-2 pt-1">
              <Button size="sm" variant="outline" className="gap-1"><Upload className="h-3.5 w-3.5" /> Upload Proof</Button>
              <Button size="sm" className="gap-1"><CheckCircle2 className="h-3.5 w-3.5" /> Mark Resolved</Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Completed() {
  const done = [
    { id: "TKT-2024-003", domain: "Internet", desc: "WiFi router reset and reconfigured", room: "305", rating: 5 },
    { id: "TKT-2024-005", domain: "Furniture", desc: "Replaced broken chair", room: "408", rating: 4 },
  ];

  return (
    <div className="space-y-4">
      {done.map(t => (
        <div key={t.id} className="rounded-xl border border-border bg-card p-5 shadow-card flex items-center justify-between">
          <div>
            <p className="font-mono text-xs text-muted-foreground">{t.id}</p>
            <p className="font-medium">{t.desc}</p>
            <p className="text-xs text-muted-foreground mt-1">Room {t.room}</p>
          </div>
          <div className="text-right">
            <StatusBadge status="Resolved" />
            <p className="text-sm mt-1">{"★".repeat(t.rating)}{"☆".repeat(5 - t.rating)}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

function Performance() {
  return (
    <div className="space-y-6">
      <div className="grid sm:grid-cols-3 gap-4">
        <StatCard label="Tasks Completed" value={24} icon={<CheckCircle2 className="h-5 w-5 text-primary" />} trend="+8 this month" />
        <StatCard label="Avg. Completion Time" value="2.1 hrs" icon={<Wrench className="h-5 w-5 text-primary" />} />
        <StatCard label="Satisfaction Rating" value="4.7/5" icon={<Star className="h-5 w-5 text-primary" />} />
      </div>
    </div>
  );
}

export default function WorkerDashboard() {
  return (
    <DashboardLayout role="worker" navItems={navItems} userName="Raju Kumar">
      <Routes>
        <Route index element={<MyTasks />} />
        <Route path="completed" element={<Completed />} />
        <Route path="performance" element={<Performance />} />
      </Routes>
    </DashboardLayout>
  );
}
