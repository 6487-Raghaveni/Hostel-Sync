import { Routes, Route } from "react-router-dom";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { StatCard, PriorityBadge, StatusBadge } from "@/components/dashboard/DashboardWidgets";
import { LayoutDashboard, FileText, Users, AlertTriangle, BarChart3, Check, X, UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const navItems = [
  { label: "Dashboard", href: "/warden", icon: <LayoutDashboard className="h-4 w-4" /> },
  { label: "All Complaints", href: "/warden/complaints", icon: <FileText className="h-4 w-4" /> },
  { label: "Escalations", href: "/warden/escalations", icon: <AlertTriangle className="h-4 w-4" /> },
  { label: "Analytics", href: "/warden/analytics", icon: <BarChart3 className="h-4 w-4" /> },
];

const complaints = [
  { id: "TKT-2024-001", student: "Priya S.", domain: "Electrical", desc: "Ceiling fan not working", room: "204", priority: "high" as const, status: "Submitted", hostel: "Girls Hostel A" },
  { id: "TKT-2024-002", student: "Rahul K.", domain: "Plumbing", desc: "Water leakage in bathroom", room: "112", priority: "high" as const, status: "Accepted", hostel: "Boys Hostel B" },
  { id: "TKT-2024-003", student: "Ananya M.", domain: "Internet", desc: "WiFi down on 3rd floor", room: "305", priority: "medium" as const, status: "Assigned", hostel: "Girls Hostel A" },
  { id: "TKT-2024-004", student: "Vikram P.", domain: "Cleaning", desc: "Common area dirty", room: "GF", priority: "low" as const, status: "In Progress", hostel: "Boys Hostel A" },
  { id: "TKT-2024-005", student: "Sneha R.", domain: "Furniture", desc: "Broken study table", room: "408", priority: "medium" as const, status: "Resolved", hostel: "Girls Hostel B" },
];

function Overview() {
  return (
    <div className="space-y-6">
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Total Complaints" value={47} icon={<FileText className="h-5 w-5 text-primary" />} />
        <StatCard label="Pending Review" value={8} icon={<AlertTriangle className="h-5 w-5 text-primary" />} trend="3 urgent" />
        <StatCard label="Avg. Resolution" value="3.8 hrs" icon={<BarChart3 className="h-5 w-5 text-primary" />} />
        <StatCard label="Worker Performance" value="92%" icon={<Users className="h-5 w-5 text-primary" />} trend="+4% this month" />
      </div>

      {/* Domain Distribution */}
      <div className="grid lg:grid-cols-2 gap-6">
        <div className="rounded-xl border border-border bg-card p-6 shadow-card">
          <h3 className="font-semibold mb-4">Domain Distribution</h3>
          <div className="space-y-3">
            {[
              { domain: "Electrical", count: 14, pct: 30 },
              { domain: "Plumbing", count: 11, pct: 23 },
              { domain: "Internet", count: 8, pct: 17 },
              { domain: "Cleaning", count: 7, pct: 15 },
              { domain: "Furniture", count: 5, pct: 11 },
              { domain: "Others", count: 2, pct: 4 },
            ].map(d => (
              <div key={d.domain}>
                <div className="flex justify-between text-sm mb-1">
                  <span>{d.domain}</span>
                  <span className="text-muted-foreground">{d.count} ({d.pct}%)</span>
                </div>
                <div className="h-2 rounded-full bg-muted overflow-hidden">
                  <div className="h-full rounded-full gradient-hero transition-all" style={{ width: `${d.pct}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-xl border border-border bg-card p-6 shadow-card">
          <h3 className="font-semibold mb-4">Recent Activity</h3>
          <div className="space-y-4">
            {[
              { action: "Accepted complaint TKT-2024-006", time: "10 min ago" },
              { action: "Assigned worker to TKT-2024-005", time: "1 hour ago" },
              { action: "Escalated TKT-2024-001 to high priority", time: "3 hours ago" },
              { action: "Resolved TKT-2024-003", time: "1 day ago" },
            ].map((a, i) => (
              <div key={i} className="flex items-center gap-3 text-sm">
                <div className="h-2 w-2 rounded-full gradient-hero flex-shrink-0" />
                <span className="flex-1">{a.action}</span>
                <span className="text-xs text-muted-foreground whitespace-nowrap">{a.time}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function AllComplaints() {
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-3">
        <Select><SelectTrigger className="w-[140px]"><SelectValue placeholder="Domain" /></SelectTrigger>
          <SelectContent>{["All", "Electrical", "Plumbing", "Internet", "Cleaning", "Furniture"].map(d => <SelectItem key={d} value={d.toLowerCase()}>{d}</SelectItem>)}</SelectContent>
        </Select>
        <Select><SelectTrigger className="w-[140px]"><SelectValue placeholder="Priority" /></SelectTrigger>
          <SelectContent>{["All", "High", "Medium", "Low"].map(d => <SelectItem key={d} value={d.toLowerCase()}>{d}</SelectItem>)}</SelectContent>
        </Select>
        <Select><SelectTrigger className="w-[140px]"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>{["All", "Submitted", "Accepted", "Assigned", "In Progress", "Resolved"].map(d => <SelectItem key={d} value={d.toLowerCase()}>{d}</SelectItem>)}</SelectContent>
        </Select>
      </div>

      <div className="rounded-xl border border-border bg-card shadow-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-border bg-muted/50">
              <th className="text-left p-3 font-medium text-muted-foreground">Ticket</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Student</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Domain</th>
              <th className="text-left p-3 font-medium text-muted-foreground hidden lg:table-cell">Room</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Priority</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Status</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Actions</th>
            </tr></thead>
            <tbody>
              {complaints.map(c => (
                <tr key={c.id} className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors">
                  <td className="p-3 font-mono text-xs">{c.id}</td>
                  <td className="p-3">{c.student}</td>
                  <td className="p-3">{c.domain}</td>
                  <td className="p-3 hidden lg:table-cell">{c.room}</td>
                  <td className="p-3"><PriorityBadge priority={c.priority} /></td>
                  <td className="p-3"><StatusBadge status={c.status} /></td>
                  <td className="p-3">
                    <div className="flex gap-1">
                      <Button size="icon" variant="ghost" className="h-7 w-7 text-success"><Check className="h-3.5 w-3.5" /></Button>
                      <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive"><X className="h-3.5 w-3.5" /></Button>
                      <Button size="icon" variant="ghost" className="h-7 w-7 text-primary"><UserPlus className="h-3.5 w-3.5" /></Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function Escalations() {
  return (
    <div className="space-y-4">
      <div className="rounded-xl border-2 border-destructive/20 bg-destructive/5 p-4 flex items-start gap-3">
        <AlertTriangle className="h-5 w-5 text-destructive flex-shrink-0 mt-0.5" />
        <div>
          <p className="font-medium text-sm">3 complaints require immediate attention</p>
          <p className="text-xs text-muted-foreground">These have exceeded the 24-hour response threshold</p>
        </div>
      </div>
      {complaints.filter(c => c.priority === "high").map(c => (
        <div key={c.id} className="rounded-xl border border-destructive/20 bg-card p-4 shadow-card flex items-center justify-between">
          <div>
            <p className="font-mono text-xs text-muted-foreground">{c.id}</p>
            <p className="font-medium">{c.desc}</p>
            <p className="text-xs text-muted-foreground mt-1">{c.hostel} • Room {c.room} • {c.student}</p>
          </div>
          <PriorityBadge priority={c.priority} />
        </div>
      ))}
    </div>
  );
}

function Analytics() {
  return (
    <div className="text-center py-12 text-muted-foreground">
      <BarChart3 className="h-12 w-12 mx-auto mb-4 opacity-30" />
      <p className="font-medium">Analytics Dashboard</p>
      <p className="text-sm">Connect to a backend to view real-time analytics</p>
    </div>
  );
}

export default function WardenDashboard() {
  return (
    <DashboardLayout role="warden" navItems={navItems} userName="Dr. Meena Gupta">
      <Routes>
        <Route index element={<Overview />} />
        <Route path="complaints" element={<AllComplaints />} />
        <Route path="escalations" element={<Escalations />} />
        <Route path="analytics" element={<Analytics />} />
      </Routes>
    </DashboardLayout>
  );
}
